﻿using Microsoft.Maui.Controls;
using System;

namespace MyGreatApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCalculateClicked(object sender, EventArgs e)
        {
            // Проверяем ввод x
            if (!double.TryParse(inputX.Text, out double x))
            {
                resultLabel.Text = "Ошибка: Введите корректное число!";
                return;
            }

            double result;

            // Выбор функции по нажатой радиокнопке
            if (shButton.IsChecked)
            {
                result = Math.Sinh(x);  // sh(x)
            }
            else if (squareButton.IsChecked)
            {
                result = Math.Pow(x, 2);  // x²
            }
            else if (expButton.IsChecked)
            {
                result = Math.Exp(x);  // e^x
            }
            else
            {
                resultLabel.Text = "Выберите функцию!";
                return;
            }

            // Вывод результата
            resultLabel.Text = $"Результат: {result:F4}";
        }
    }
}
