﻿using Microsoft.Maui.Controls;
using System;

namespace MyGreatApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnSaveClicked(object sender, EventArgs e)
        {
            // Собираем данные из формы
            string employeeData = $"Анкетные данные:\n" +
                                  $"Фамилия: {inputLastName.Text}\n" +
                                  $"Имя: {inputFirstName.Text}\n" +
                                  $"Отчество: {inputMiddleName.Text}\n" +
                                  $"Дата рождения: {birthDatePicker.Date:dd MMMM yyyy}\n" +
                                  $"Место проживания: {inputResidence.Text}\n" +
                                  $"Email: {inputEmail.Text}\n" +
                                  $"Телефон: {inputPhone.Text}\n" +
                                  $"Опыт работы: {experiencePicker.SelectedItem}\n" +
                                  $"Личное авто: {(hasCarCheckBox.IsChecked ? "Да" : "Нет")}\n" +
                                  $"Водительские права: {(hasLicenseCheckBox.IsChecked ? "Да" : "Нет")}\n" +
                                  $"Зарплата: От {inputSalaryFrom.Text} до {inputSalaryTo.Text}\n" +
                                  $"График работы: {schedulePicker.SelectedItem}\n" +
                                  $"Резюме: {inputResume.Text}";

            Console.WriteLine(employeeData); // Вывод в консоль или сохранение
            DisplayAlert("Успех", "Данные сохранены!", "ОК");
        }

        private void OnClearClicked(object sender, EventArgs e)
        {
            // Очистка всех полей формы
            inputLastName.Text = "";
            inputFirstName.Text = "";
            inputMiddleName.Text = "";
            inputResidence.Text = "";
            inputEmail.Text = "";
            inputPhone.Text = "";
            inputSalaryFrom.Text = "";
            inputSalaryTo.Text = "";
            inputResume.Text = "";
            experiencePicker.SelectedIndex = -1;
            schedulePicker.SelectedIndex = -1;
            hasCarCheckBox.IsChecked = false;
            hasLicenseCheckBox.IsChecked = false;
        }
    }
}
