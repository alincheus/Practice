﻿using Microsoft.Maui.Controls;

namespace MyCoolApp;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private void buttonRun_Click(object sender, EventArgs e)
    {
        DisplayAlert("Приветствие", $"Hello {textboxName.Text}", "OK");
    }

    private void buttonAbout_Click(object sender, EventArgs e)
    {
        Navigation.PushAsync(new HelpPage());
    }

    private void buttonClose_Click(object sender, EventArgs e)
    {
        Application.Current.Quit();
    }
}
