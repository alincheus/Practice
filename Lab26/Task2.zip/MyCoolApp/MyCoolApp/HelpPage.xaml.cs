﻿namespace MyCoolApp;

public partial class HelpPage : ContentPage
{
    public HelpPage()
    {
        InitializeComponent();
    }

    private void buttonClose_Click(object sender, EventArgs e)
    {
        Navigation.PopAsync();
    }
}
