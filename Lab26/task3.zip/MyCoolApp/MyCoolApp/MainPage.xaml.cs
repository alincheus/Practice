﻿using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;
using System.Collections.Generic;

namespace MyCoolApp;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private void OnPlotGraphClicked(object sender, EventArgs e)
    {
        if (double.TryParse(entryA.Text, out double a) &&
            double.TryParse(entryB.Text, out double b) &&
            double.TryParse(entryH.Text, out double h))
        {
            graphView.Drawable = new GraphDrawable(a, b, h);
            graphView.Invalidate();
        }
        else
        {
            DisplayAlert("Ошибка", "Введите корректные значения!", "OK");
        }
    }
}

public class GraphDrawable : IDrawable
{
    private readonly double a, b, h;
    private readonly List<(float x, float y)> points = new();

    public GraphDrawable(double a, double b, double h)
    {
        this.a = a;
        this.b = b;
        GenerateData();
    }

    private void GenerateData()
    {
        for (float x = -10; x <= 10; x += (float)h)
        {
            float y = (float)(a * x + b);
            points.Add((x, y));
        }
    }

    public void Draw(ICanvas canvas, RectF dirtyRect)
    {
        canvas.StrokeColor = Colors.Blue;
        canvas.StrokeSize = 3;

        // Рисуем оси
        canvas.DrawLine(0, dirtyRect.Height / 2, dirtyRect.Width, dirtyRect.Height / 2);
        canvas.DrawLine(dirtyRect.Width / 2, 0, dirtyRect.Width / 2, dirtyRect.Height);

        // Рисуем график
        for (int i = 1; i < points.Count; i++)
        {
            float x1 = dirtyRect.Width / 2 + points[i - 1].x * 20;
            float y1 = dirtyRect.Height / 2 - points[i - 1].y * 20;
            float x2 = dirtyRect.Width / 2 + points[i].x * 20;
            float y2 = dirtyRect.Height / 2 - points[i].y * 20;

            canvas.DrawLine(x1, y1, x2, y2);
        }
    }
}
