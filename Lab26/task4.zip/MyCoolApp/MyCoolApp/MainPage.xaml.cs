﻿using Microsoft.Maui.Controls;

namespace MyCoolApp;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private void OnButtonTap(object sender, EventArgs e)
    {
        Button newButton = new()
        {
            Text = "Нажми, чтобы удалить"
        };

        var tapGesture = new TapGestureRecognizer();
        tapGesture.Tapped += OnButtonRemove;
        newButton.GestureRecognizers.Add(tapGesture);

    }

    private void OnButtonRemove(object sender, EventArgs e)
    {
        if (sender is Button button)
        {
            buttonContainer.Children.Remove(button);
        }
    }
}
