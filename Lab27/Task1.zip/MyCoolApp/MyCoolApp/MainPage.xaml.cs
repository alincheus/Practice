﻿using Microsoft.Maui.Storage;
using System.Xml.Linq;

namespace MyCoolApp;

public partial class MainPage : ContentPage
{
    private readonly string xmlFilePath;

    public MainPage()
    {
        InitializeComponent();
        xmlFilePath = Path.Combine(FileSystem.Current.AppDataDirectory, "Library.xml");
        btnAdd.IsEnabled = false;
    }

    private void btnLoad_Click(object sender, EventArgs e)
    {
        if (!File.Exists(xmlFilePath))
        {
            File.WriteAllText(xmlFilePath, "<library></library>");
        }

        XDocument doc = XDocument.Load(xmlFilePath);
        var books = doc.Root.Elements("book");

        libraryLabel.Text = "";
        foreach (var book in books)
        {
            libraryLabel.Text += $"📖 {book.Element("title")?.Value} - {book.Element("author")?.Value} ({book.Element("year")?.Value})\n";
        }

        btnAdd.IsEnabled = true;
    }

    private async void btnAdd_Click(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new AddBookPage(xmlFilePath));
    }
}
