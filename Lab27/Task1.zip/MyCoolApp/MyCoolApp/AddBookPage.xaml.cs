﻿using System.Xml.Linq;

namespace MyCoolApp;

public partial class AddBookPage : ContentPage
{
    private readonly string xmlFilePath;

    public AddBookPage(string filePath)
    {
        InitializeComponent();
        xmlFilePath = filePath;
    }

    private async void btnSave_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(entryTitle.Text) ||
            string.IsNullOrWhiteSpace(entryAuthor.Text) ||
            string.IsNullOrWhiteSpace(entryYear.Text))
        {
            await DisplayAlert("Ошибка", "Заполните все поля!", "OK");
            return;
        }

        XDocument doc = XDocument.Load(xmlFilePath);
        XElement newBook = new XElement("book",
            new XElement("title", entryTitle.Text),
            new XElement("author", entryAuthor.Text),
            new XElement("year", entryYear.Text));

        doc.Root?.Add(newBook);
        doc.Save(xmlFilePath);

        await DisplayAlert("Готово", "Книга добавлена!", "OK");
        await Navigation.PopAsync();
    }
}
