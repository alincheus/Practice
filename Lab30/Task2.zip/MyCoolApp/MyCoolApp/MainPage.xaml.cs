﻿using Microsoft.Maui.Controls;
using MyCoolApp;
using System;
using System.Timers;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private System.Timers.Timer _timer;

        public MainPage()
        {
            InitializeComponent();
            CanvasView.Drawable = new ScrollingTextDrawable();

            _timer = new System.Timers.Timer(50);
            _timer.Elapsed += OnTimerTick;
            _timer.AutoReset = true;
        }

        private void OnTimerTick(object sender, ElapsedEventArgs e)
        {
            Dispatcher.Dispatch(() =>
            {
                ScrollingTextDrawable.UpdatePosition();
                CanvasView.Invalidate(); // Принудительное обновление UI
            });
        }

        private void OnStartClicked(object sender, EventArgs e)
        {
            if (!_timer.Enabled)
            {
                _timer.Start();
            }
        }
    }
}
