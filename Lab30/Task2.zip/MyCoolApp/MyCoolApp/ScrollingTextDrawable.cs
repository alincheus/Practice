﻿using Microsoft.Maui.Graphics;

namespace MyCoolApp
{
    public class ScrollingTextDrawable : IDrawable
    {
        private static float _x = 300;
        private static readonly float _speed = 2;

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.FontColor = Colors.Black;
            canvas.FontSize = 30;
            canvas.DrawString("Бегущая строка!", _x, 50, HorizontalAlignment.Left);
        }

        public static void UpdatePosition()
        {
            _x -= _speed;
            if (_x < -200) _x = 300; // Возвращаем текст в начало
        }
    }
}
