﻿using Microsoft.Maui.Controls;
using MyCoolApp;
using System;
using System.Timers;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private System.Timers.Timer _timer;

        public MainPage()
        {
            InitializeComponent();
            CanvasView.Drawable = new ClockDrawable();

            _timer = new System.Timers.Timer(1000); 
            _timer.Elapsed += (s, e) =>
            {
                ClockDrawable.UpdateTime();
                Dispatcher.Dispatch(() => CanvasView.Invalidate());
            };
            _timer.AutoReset = true;
            _timer.Start();
        }
    }
}
