﻿using Microsoft.Maui.Graphics;
using System;

namespace MyCoolApp
{
    public class ClockDrawable : IDrawable
    {
        private static float _secondAngle = 0;

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            float centerX = dirtyRect.Width / 2;
            float centerY = dirtyRect.Height / 2;
            float radius = Math.Min(centerX, centerY) - 10;

            // Рисуем циферблат
            canvas.StrokeSize = 4;
            canvas.StrokeColor = Colors.Black;
            canvas.DrawCircle(centerX, centerY, radius);

            // Вычисляем положение конца секундной стрелки
            float secX = centerX + (float)(radius * 0.9 * Math.Cos(Math.PI * _secondAngle / 180));
            float secY = centerY + (float)(radius * 0.9 * Math.Sin(Math.PI * _secondAngle / 180));

            // Рисуем секундную стрелку
            canvas.StrokeSize = 2;
            canvas.StrokeColor = Colors.Red;
            canvas.DrawLine(centerX, centerY, secX, secY);
        }

        public static void UpdateTime()
        {
            _secondAngle += 6; // 6 градусов = 1 секунда
            if (_secondAngle >= 360) _secondAngle = 0;
        }
    }
}
