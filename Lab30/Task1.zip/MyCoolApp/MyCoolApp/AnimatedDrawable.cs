﻿using Microsoft.Maui.Graphics;

namespace MyCoolApp
{
    public class AnimatedDrawable : IDrawable
    {
        private static float _x = 50;
        private static float _direction = 5;

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.FillColor = Colors.Blue;
            canvas.FillCircle(_x, 200, 30);
        }

        public static void UpdatePosition()
        {
            _x += _direction;
            if (_x >= 350 || _x <= 50)
                _direction *= -1; 
        }
    }
}
