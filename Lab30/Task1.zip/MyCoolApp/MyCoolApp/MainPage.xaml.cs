﻿using Microsoft.Maui.Controls;
using MyCoolApp;
using System;
using System.Timers; 

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private System.Timers.Timer _timer; // Указываем пространство имен явно

        public MainPage()
        {
            InitializeComponent();
            CanvasView.Drawable = new AnimatedDrawable();

            _timer = new System.Timers.Timer(50); // Таймер с интервалом 50 мс
            _timer.Elapsed += (s, e) =>
            {
                AnimatedDrawable.UpdatePosition();
                Dispatcher.Dispatch(() => CanvasView.Invalidate()); // Обновление UI
            };
        }

        private void OnStartClicked(object sender, EventArgs e)
        {
            _timer.Start();
        }
    }
}
