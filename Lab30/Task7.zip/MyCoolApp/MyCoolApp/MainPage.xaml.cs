﻿using Microsoft.Maui.Controls;
using MyCoolApp;
using System;
using System.Timers;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private System.Timers.Timer _timer;

        public MainPage()
        {
            InitializeComponent();
            CanvasView.Drawable = new SinusoidDrawable();

            _timer = new System.Timers.Timer(50);
            _timer.Elapsed += (s, e) =>
            {
                SinusoidDrawable.UpdatePosition();
                Dispatcher.Dispatch(() => CanvasView.Invalidate());
            };
            _timer.AutoReset = true;
        }

        private void OnStartClicked(object sender, EventArgs e)
        {
            if (!_timer.Enabled)
            {
                _timer.Start();
            }
        }
    }
}
