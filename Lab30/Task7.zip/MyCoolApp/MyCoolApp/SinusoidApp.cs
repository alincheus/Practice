﻿using Microsoft.Maui.Graphics;
using System;

namespace MyCoolApp
{
    public class SinusoidDrawable : IDrawable
    {
        private static float _x = 0, _y = 150;
        private static float _speed = 5;
        private static float _frequency = 50;
        private static float _angle = 0;

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.FillColor = Colors.White;
            canvas.FillRectangle(dirtyRect);

            canvas.StrokeColor = Colors.Gray;
            canvas.StrokeSize = 2;
            canvas.DrawLine(0, 150, dirtyRect.Width, 150);

            canvas.FillColor = Colors.Blue;
            canvas.FillCircle(_x, _y, 10);
        }

        public static void UpdatePosition()
        {
            _x += _speed;
            _y = 150 + (float)(Math.Sin(_angle) * _frequency);
            _angle += 0.1f;

            if (_x > 300) _x = 0; 
        }
    }
}
