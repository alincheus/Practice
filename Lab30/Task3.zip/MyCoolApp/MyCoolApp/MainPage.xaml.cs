﻿using Microsoft.Maui.Controls;
using System;
using System.Timers;
using MyCoolApp;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private System.Timers.Timer _timer;

        public MainPage()
        {
            InitializeComponent();
            CanvasView.Drawable = new TrajectoryDrawable();

            _timer = new System.Timers.Timer(50);
            _timer.Elapsed += OnTimerTick;
            _timer.AutoReset = true;
        }

        private void OnTimerTick(object sender, ElapsedEventArgs e)
        {
            Dispatcher.Dispatch(() =>
            {
                TrajectoryDrawable.UpdatePosition();
                CanvasView.Invalidate(); // Принудительно обновляем экран
            });
        }

        private void OnStartClicked(object sender, EventArgs e)
        {
            if (!_timer.Enabled)
            {
                _timer.Start();
            }
        }
    }
}
