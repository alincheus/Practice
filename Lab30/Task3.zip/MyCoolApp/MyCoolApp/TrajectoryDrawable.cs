﻿using Microsoft.Maui.Graphics;
using System;

namespace MyCoolApp
{
    public class TrajectoryDrawable : IDrawable
    {
        private static float _x2, _y2;
        private static double _a = 150, _fi = -0.5;

        public TrajectoryDrawable()
        {
            UpdatePosition(); // Первичное вычисление координат
        }

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            // Устанавливаем белый фон
            canvas.FillColor = Colors.White;
            canvas.FillRectangle(dirtyRect);

            canvas.StrokeSize = 2;
            canvas.StrokeColor = Colors.DarkRed;

            // Рисуем движущуюся окружность
            canvas.DrawCircle(_x2, _y2, 10);
        }

        public static void UpdatePosition()
        {
            double t = Math.Tan(_fi);
            _x2 = 200 + (float)((3 * _a * t) / (1 + t * t * t));
            _y2 = 200 - (float)((3 * _a * t * t) / (1 + t * t * t));

            _fi += 0.05; // Двигаемся по траектории
        }
    }
}
