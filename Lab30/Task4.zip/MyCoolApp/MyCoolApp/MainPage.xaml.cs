﻿using Microsoft.Maui.Controls;
using System;
using System.Timers;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private System.Timers.Timer _timer;
        private float _x = -40, _y = 100;
        private int _speed = 3;
        private Random _rnd = new Random();

        public MainPage()
        {
            InitializeComponent();
            PlaneImage.TranslationX = _x;
            PlaneImage.TranslationY = _y;

            _timer = new System.Timers.Timer(50);
            _timer.Elapsed += (s, e) =>
            {
                Dispatcher.Dispatch(() =>
                {
                    UpdatePosition();
                });
            };
            _timer.AutoReset = true;
        }

        private void OnStartClicked(object sender, EventArgs e)
        {
            if (!_timer.Enabled)
            {
                _timer.Start();
            }
        }

        private void UpdatePosition()
        {
            _x += _speed;
            if (_x > 400)
            {
                _x = -40;
                _y = _rnd.Next(50, 300);
                _speed = _rnd.Next(2, 5);
            }

            PlaneImage.TranslationX = _x;
            PlaneImage.TranslationY = _y;
        }
    }
}
