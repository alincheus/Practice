﻿using Microsoft.Maui.Controls;
using System;
using System.Timers;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private System.Timers.Timer _timer;
        private float _y = 0.8f;
        private float _speed = 0.01f;

        public MainPage()
        {
            InitializeComponent();
            _timer = new System.Timers.Timer(50);
            _timer.Elapsed += (s, e) =>
            {
                Dispatcher.Dispatch(() =>
                {
                    UpdatePosition();
                });
            };
            _timer.AutoReset = true;
        }

        private void OnStartClicked(object sender, EventArgs e)
        {
            if (!_timer.Enabled)
            {
                _timer.Start();
            }
        }

        private void UpdatePosition()
        {
            if (_y > 0.2f)
            {
                _y -= _speed;
                var newBounds = new Rect(0.5, _y, RocketImage.WidthRequest, RocketImage.HeightRequest);
                RocketImage.SetValue(AbsoluteLayout.LayoutBoundsProperty, newBounds);
            }
            else
            {
                _timer.Stop(); 
            }
        }
    }
}
