﻿using Microsoft.Maui.Graphics;
using System;
using System.IO;

namespace MyCoolApp.Graphics
{
    public class FlightDrawable : IDrawable
    {
        private static float _x = -40, _y = 100;
        private static int _speed = 2;
        private static Random _rnd = new Random();
        private static Microsoft.Maui.Graphics.IImage _planeImage = LoadImage("plane.bmp");
        private static Microsoft.Maui.Graphics.IImage _skyImage = LoadImage("sky.bmp");

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            if (_skyImage != null)
            {
                canvas.DrawImage(_skyImage, 0, 0, dirtyRect.Width, dirtyRect.Height);
            }
            else
            {
                canvas.FillColor = Colors.LightBlue;
                canvas.FillRectangle(dirtyRect);
            }

            if (_planeImage != null)
            {
                canvas.DrawImage(_planeImage, _x, _y, 80, 60);
            }
        }

        public static void UpdatePosition()
        {
            _x += _speed;
            if (_x > 400)
            {
                _x = -40;
                _y = _rnd.Next(50, 300);
                _speed = _rnd.Next(2, 5);
            }

            Console.WriteLine($"Самолет в позиции X: {_x}, Y: {_y}"); 
        }

        private static Microsoft.Maui.Graphics.IImage LoadImage(string filename)
        {
            try
            {
                string path = Path.Combine(FileSystem.AppDataDirectory, filename);
                if (!File.Exists(path))
                {
                    Console.WriteLine($"Файл {filename} не найден!");
                    return null;
                }

                using FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read);
                return Microsoft.Maui.Graphics.Platform.PlatformImage.FromStream(stream);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка загрузки изображения {filename}: {ex.Message}");
                return null;
            }
        }
    }
}
