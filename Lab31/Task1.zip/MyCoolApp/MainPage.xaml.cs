﻿using System.Collections.ObjectModel;
using Microsoft.Maui.Controls;
using MyCoolApp.Services;
using Npgsql;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private readonly DatabaseService _databaseService = new DatabaseService();

        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnAddTouristClicked(object sender, System.EventArgs e)
        {
            _databaseService.ДобавитьТуриста("Алина", "Петрова", "Ивановна");
            await DisplayAlert("✅", "Турист добавлен", "OK");
        }

        private async void OnDeleteTouristClicked(object sender, System.EventArgs e)
        {
            _databaseService.УдалитьТуриста(1); // ID туриста для удаления
            await DisplayAlert("✅", "Турист удален", "OK");
        }

        private async void OnUpdateTouristClicked(object sender, System.EventArgs e)
        {
            _databaseService.ИзменитьТуриста(2, "Мария", "Сидорова", "Александровна");
            await DisplayAlert("✅", "Данные туриста обновлены", "OK");
        }

        private async void OnConnectClicked(object sender, EventArgs e)
        {
            try
            {
                using var connection = new NpgsqlConnection("Host=localhost;Port=5433;Username=postgres;Password=1234;Database=DBTur_firm");
                connection.Open();
                await DisplayAlert("✅ Успех", "Подключение к базе данных выполнено!", "OK");
            }
            catch (Exception ex)
            {
                await DisplayAlert("❌ Ошибка", $"Ошибка подключения: {ex.Message}", "OK");
            }
        }

        private async void OnSelectToursClicked(object sender, System.EventArgs e)
        {
            var туры = _databaseService.ПолучитьТуры();
            var list = new ObservableCollection<string>();

            foreach (var тур in туры)
                list.Add($"{тур.Код}: {тур.Название} - {тур.Цена}");

            ToursList.ItemsSource = list;
        }
    }
}
