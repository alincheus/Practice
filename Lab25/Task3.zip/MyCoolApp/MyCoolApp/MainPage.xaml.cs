﻿using System;

using Microsoft.Maui.Controls;


namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnToggleClockClicked(object sender, EventArgs e)
        {
            clock.TimeEnabled = !clock.TimeEnabled;

            ((Button)sender).Text = clock.TimeEnabled ? "Выключить часы" : "Включить часы";
        }

        private void OnUpdateProgressClicked(object sender, EventArgs e)
        {
            progressCircle.Progress += 0.1f;
        }

    }
}