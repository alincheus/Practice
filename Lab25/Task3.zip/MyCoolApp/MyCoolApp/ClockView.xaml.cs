﻿using System;
using Microsoft.Maui;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Dispatching;

namespace MyCoolApp;

public partial class ClockView : ContentView
{
    private readonly IDispatcherTimer timer;
    private readonly ClockDrawable clockDrawable;

    public ClockView()
    {
        InitializeComponent();

        // Инициализируем clockDrawable
        clockDrawable = new ClockDrawable();
        graphicsView.Drawable = clockDrawable; // Назначаем его GraphicsView

        // Создаём таймер
        timer = Application.Current.Dispatcher.CreateTimer();
        timer.Interval = TimeSpan.FromSeconds(1);
        timer.Tick += (s, e) => UpdateTime();
        timer.Start();
    }

    private void UpdateTime()
    {
        if (clockDrawable != null) // Проверяем, что объект инициализирован
        {
            clockDrawable.CurrentTime = DateTime.Now.ToLongTimeString();
            graphicsView.Invalidate();
        }
    }

    public bool TimeEnabled
    {
        get => timer.IsRunning;
        set
        {
            if (value)
                timer.Start();
            else
                timer.Stop();
        }
    }
}
