﻿using Microsoft.Maui.Graphics;
using Microsoft.Maui.Controls;

namespace MyCoolApp;

public class ProgressCircle : GraphicsView
{
    private float progress = 0;

    public float Progress
    {
        get => progress;
        set
        {
            progress = Math.Clamp(value, 0, 1);
            Invalidate(); // Обновляем отрисовку
        }
    }

    public ProgressCircle()
    {
        Drawable = new ProgressDrawable(this);
        HeightRequest = 100;
        WidthRequest = 100;
    }

    private class ProgressDrawable : IDrawable
    {
        private readonly ProgressCircle parent;

        public ProgressDrawable(ProgressCircle parent) => this.parent = parent;

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            float progressAngle = parent.Progress * 360;

            // Фон круга
            canvas.FillColor = Colors.LightGray;
            canvas.FillEllipse(dirtyRect);

            // Прогресс
            canvas.StrokeColor = Colors.Blue;
            canvas.StrokeSize = 8;
            canvas.DrawArc(dirtyRect, 270, 270 + progressAngle, true, false);
        }
    }
}
