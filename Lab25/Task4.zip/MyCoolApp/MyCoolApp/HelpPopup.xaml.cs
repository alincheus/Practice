﻿namespace MyCoolApp;

public partial class HelpPopup : ContentView
{
    public static readonly BindableProperty IsVisibleProperty =
        BindableProperty.Create(nameof(IsVisible), typeof(bool), typeof(HelpPopup), false, propertyChanged: OnIsVisibleChanged);

    public bool IsVisible
    {
        get => (bool)GetValue(IsVisibleProperty);
        set => SetValue(IsVisibleProperty, value);
    }

    private static void OnIsVisibleChanged(BindableObject bindable, object oldValue, object newValue)
    {
        ((HelpPopup)bindable).IsVisible = (bool)newValue;
    }

    private void OnCloseHelpClicked(object sender, EventArgs e)
    {
        this.IsVisible = false;
    }

}

