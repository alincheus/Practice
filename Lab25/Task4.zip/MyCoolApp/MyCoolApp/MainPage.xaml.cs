﻿using System;
using System.Resources;
using System.Globalization;


using Microsoft.Maui.Controls;


namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private ResourceManager RM = new ResourceManager("MyCoolApp.Resources", typeof(MainPage).Assembly);

        public MainPage()
        {
            InitializeComponent();
            string welcomeText = RM.GetString("WelcomeMessage", CultureInfo.CurrentUICulture);
            welcomeLabel.Text = welcomeText;
        }

        private void OnToggleClockClicked(object sender, EventArgs e)
        {
            clock.TimeEnabled = !clock.TimeEnabled;

            ((Button)sender).Text = clock.TimeEnabled ? "Выключить часы" : "Включить часы";
        }

        private void OnUpdateProgressClicked(object sender, EventArgs e)
        {
            progressCircle.Progress += 0.1f;
        }

        private void OnHelpClicked(object sender, EventArgs e)
        {
            helpPopup.IsVisible = true;
        }

        private void OnButtonHover(object sender, EventArgs e)
        {
            var btn = (Button)sender;
            btn.Text = "Подсказка: нажмите, чтобы сложить числа";
        }

    }
}