﻿using Microsoft.Maui.Graphics;
using System;

namespace MyCoolApp
{
    public class ClockDrawable : IDrawable
    {
        public string CurrentTime { get; set; } = DateTime.Now.ToLongTimeString();
        public static ClockDrawable Instance { get; } = new ClockDrawable();


        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            // Заливаем фон (синий)
            canvas.FillColor = Colors.Blue;
            canvas.FillRectangle(dirtyRect);

            // Настройки шрифта
            canvas.FontColor = Colors.White;
            canvas.FontSize = 24;
            canvas.Font = Microsoft.Maui.Graphics.Font.Default;

            // Отрисовка текста
            canvas.DrawString(CurrentTime, dirtyRect.Width / 2, dirtyRect.Height / 2, HorizontalAlignment.Center);
        }
    }
}