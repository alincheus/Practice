﻿using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;

namespace MyCoolApp;

public class ClickButton : Button
{
    private int _clicks;

    public int Clicks => _clicks;

    public ClickButton()
    {
        Clicked += OnClick;
    }

    private void OnClick(object sender, EventArgs e)
    {
        _clicks++;
        UpdateText();
    }

    private void UpdateText()
    {
        Text = $"Нажатий: {_clicks}";
    }
}
