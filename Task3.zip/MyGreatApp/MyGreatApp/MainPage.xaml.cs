﻿using Microsoft.Maui.Controls;
using System;
using System.Text;

namespace MyGreatApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCalculateClicked(object sender, EventArgs e)
        {

            if (!double.TryParse(inputA.Text, out double a) ||
            !double.TryParse(inputB.Text, out double b) ||
                !double.TryParse(inputC.Text, out double c))
            {
                resultLabel.Text = "Ошибка: Введите корректные параметры!";
                return;
            }

            double x0 = -1.5, xk = 3.5, dx = 0.5;
            StringBuilder results = new StringBuilder("Таблица значений:\n");

            for (double x = x0; x <= xk; x += dx)
            {
                double y = 0.01 * (b * c / x) + Math.Cos(Math.Pow(a, 1.0 / 3) * x);
                results.AppendLine($"x = {x:F2}, y(x) = {y:F4}");
            }

            resultLabel.Text = results.ToString();
        }
    }
}
