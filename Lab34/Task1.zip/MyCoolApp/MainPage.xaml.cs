﻿using Microsoft.Maui.Controls;
using MyCoolApp.Services;
using System.Collections.ObjectModel;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private readonly DatabaseService _databaseService = new DatabaseService();

        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnAddTouristClicked(object sender, EventArgs e)
        {
            string имя = NameEntry.Text;
            string фамилия = SurnameEntry.Text;
            string отчество = PatronymicEntry.Text;

            if (!string.IsNullOrWhiteSpace(имя) && !string.IsNullOrWhiteSpace(фамилия))
            {
                _databaseService.ДобавитьТуриста(имя, фамилия, отчество);
                await DisplayAlert("✅", "Турист добавлен", "OK");
            }
            else
            {
                await DisplayAlert("❌", "Введите имя и фамилию!", "OK");
            }
        }

        private async void OnDeleteTouristClicked(object sender, EventArgs e)
        {
            if (int.TryParse(TouristIdEntry.Text, out int id))
            {
                _databaseService.УдалитьТуриста(id);
                await DisplayAlert("✅", $"Турист с ID {id} удален", "OK");
            }
            else
            {
                await DisplayAlert("❌", "Введите корректный ID!", "OK");
            }
        }

        private async void OnUpdateTouristClicked(object sender, EventArgs e)
        {
            if (int.TryParse(TouristIdEntry.Text, out int id))
            {
                string имя = NameEntry.Text;
                string фамилия = SurnameEntry.Text;
                string отчество = PatronymicEntry.Text;

                _databaseService.ИзменитьТуриста(id, имя, фамилия, отчество);
                await DisplayAlert("✅", $"Данные туриста с ID {id} обновлены", "OK");
            }
            else
            {
                await DisplayAlert("❌", "Введите корректный ID!", "OK");
            }
        }

        private async void OnSelectTouristsClicked(object sender, EventArgs e)
        {
            var туристы = _databaseService.ПолучитьТуристов();
            var list = new ObservableCollection<string>();

            foreach (var tourist in туристы)
                list.Add($"{tourist.TouristCode}: {tourist.FirstName} {tourist.LastName}");

            TouristsList.ItemsSource = list;
        }
    }
}
