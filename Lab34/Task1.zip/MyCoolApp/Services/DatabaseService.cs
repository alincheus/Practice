﻿using MyCoolApp.Models;
using System.Linq;

namespace MyCoolApp.Services
{
    public class DatabaseService
    {
        public List<Tourist> ПолучитьТуристов()
        {
            using var db = new DatabaseContext();
            return db.Tourists.ToList();
        }

        public void ДобавитьТуриста(string имя, string фамилия, string отчество)
        {
            using var db = new DatabaseContext();
            var newTourist = new Tourist { FirstName = имя, LastName = фамилия, Patronymic = отчество };

            db.Tourists.Add(newTourist);
            db.SaveChanges();
        }

        public void УдалитьТуриста(int id)
        {
            using var db = new DatabaseContext();
            var tourist = db.Tourists.FirstOrDefault(t => t.TouristCode == id);
            if (tourist != null)
            {
                db.Tourists.Remove(tourist);
                db.SaveChanges();
            }
        }

        public void ИзменитьТуриста(int id, string имя, string фамилия, string отчество)
        {
            using var db = new DatabaseContext();
            var tourist = db.Tourists.FirstOrDefault(t => t.TouristCode == id);
            if (tourist != null)
            {
                tourist.FirstName = имя;
                tourist.LastName = фамилия;
                tourist.Patronymic = отчество;
                db.SaveChanges();
            }
        }
    }
}
