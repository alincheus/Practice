﻿using System.ComponentModel.DataAnnotations;

namespace MyCoolApp.Models
{
    public class Tour
    {
        [Key]
        public int TourCode { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}
