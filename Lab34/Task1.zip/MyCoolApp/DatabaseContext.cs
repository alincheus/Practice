﻿using Microsoft.EntityFrameworkCore;
using MyCoolApp.Models;

namespace MyCoolApp
{
    public class DatabaseContext : DbContext
    {
        public DbSet<Tourist> Tourists { get; set; }
        public DbSet<Tour> Tours { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Port=5433;Username=postgres;Password=1234;Database=DBTur_firm");
        }
    }
}
