﻿namespace MyCoolApp.Models
{
    public class Тур
    {
        public int Код { get; set; }
        public string Название { get; set; }
        public decimal Цена { get; set; }
        public string Информация { get; set; }
    }

    public class Турист
    {
        public int Код { get; set; }
        public string Фамилия { get; set; }
        public string Имя { get; set; }
        public string Отчество { get; set; }
    }

    public class Оплата
    {
        public int КодОплаты { get; set; }
        public int КодПутевки { get; set; }
        public DateTime ДатаОплаты { get; set; }
        public decimal Сумма { get; set; }
    }

}
