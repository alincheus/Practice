﻿using System.Collections.ObjectModel;
using Microsoft.Maui.Controls;
using MyCoolApp.Services;
using Npgsql;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private readonly DatabaseService _databaseService = new DatabaseService();

        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnAddTouristClicked(object sender, EventArgs e)
        {
            string имя = NameEntry.Text;
            string фамилия = SurnameEntry.Text;
            string отчество = PatronymicEntry.Text;

            if (!string.IsNullOrWhiteSpace(имя) && !string.IsNullOrWhiteSpace(фамилия))
            {
                _databaseService.ДобавитьТуриста(имя, фамилия, отчество);
                await DisplayAlert("✅", "Турист добавлен", "OK");
            }
            else
            {
                await DisplayAlert("❌", "Введите имя и фамилию!", "OK");
            }
        }

        private async void OnDeleteTouristClicked(object sender, EventArgs e)
        {
            if (int.TryParse(TouristIdEntry.Text, out int id))
            {
                _databaseService.УдалитьТуриста(id);
                await DisplayAlert("✅", $"Турист с ID {id} удален", "OK");
            }
            else
            {
                await DisplayAlert("❌", "Введите корректный ID!", "OK");
            }
        }

        private async void OnUpdateTouristClicked(object sender, EventArgs e)
        {
            if (int.TryParse(TouristIdEntry.Text, out int id))
            {
                string имя = NameEntry.Text;
                string фамилия = SurnameEntry.Text;
                string отчество = PatronymicEntry.Text;

                _databaseService.ИзменитьТуриста(id, имя, фамилия, отчество);
                await DisplayAlert("✅", $"Данные туриста с ID {id} обновлены", "OK");
            }
            else
            {
                await DisplayAlert("❌", "Введите корректный ID!", "OK");
            }
        }

        private async void OnConnectClicked(object sender, EventArgs e)
        {
            try
            {
                using var connection = new NpgsqlConnection("Host=localhost;Port=5433;Username=postgres;Password=1234;Database=DBTur_firm");
                connection.Open();
                await DisplayAlert("✅ Успех", "Подключение к базе данных выполнено!", "OK");
            }
            catch(Exception ex)
            {
                await DisplayAlert("❌ Ошибка", $"Ошибка подключения: {ex.Message}", "OK");
            }
        }

        private async void OnSelectToursClicked(object sender, System.EventArgs e)
        {
            var туры = _databaseService.ПолучитьТуры();
            var list = new ObservableCollection<string>();
            foreach (var тур in туры) list.Add($"{тур.Код}: {тур.Название} - {тур.Цена}"); ToursList.ItemsSource = list;
        }
    }
}
  