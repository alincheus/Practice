﻿using Npgsql;
using System.Collections.Generic;
using MyCoolApp.Models;

namespace MyCoolApp.Services
{
    public class DatabaseService
    {
        private const string ConnectionString = "Host=localhost;Port=5433;Username=postgres;Password=1234;Database=DBTur_firm";

        public void ДобавитьТуриста(string имя, string фамилия, string отчество)
        {
            using var connection = new NpgsqlConnection(ConnectionString);
            connection.Open();

            string query = "INSERT INTO tourists (first_name, last_name, patronymic) VALUES (@first_name, @last_name, @patronymic)";
            using var cmd = new NpgsqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@first_name", имя);
            cmd.Parameters.AddWithValue("@last_name", фамилия);
            cmd.Parameters.AddWithValue("@patronymic", отчество ?? "");

            cmd.ExecuteNonQuery();
        }

        public void УдалитьТуриста(int id)
        {
            using var connection = new NpgsqlConnection(ConnectionString);
            connection.Open();

            string query = "DELETE FROM tourists WHERE tourist_code = @tourist_code";
            using var cmd = new NpgsqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@tourist_code", id);

            cmd.ExecuteNonQuery();
        }

        public void ИзменитьТуриста(int id, string имя, string фамилия, string отчество)
        {
            using var connection = new NpgsqlConnection(ConnectionString);
            connection.Open();

            string query = "UPDATE tourists SET first_name = @first_name, last_name = @last_name, patronymic = @patronymic WHERE tourist_code = @tourist_code";
            using var cmd = new NpgsqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@first_name", имя);
            cmd.Parameters.AddWithValue("@last_name", фамилия);
            cmd.Parameters.AddWithValue("@patronymic", отчество);
            cmd.Parameters.AddWithValue("@tourist_code", id);

            cmd.ExecuteNonQuery();
        }

        public List<Тур> ПолучитьТуры()
        {
            var туры = new List<Тур>();
            using var connection = new NpgsqlConnection(ConnectionString);
            connection.Open();
            string query = "SELECT toure_code, name, price, information FROM tours";
            using var cmd = new NpgsqlCommand(query, connection);
            using var reader = cmd.ExecuteReader(); while (reader.Read())
            {
                туры.Add(new Тур { Код = reader.GetInt32(0), Название = reader.GetString(1), Цена = reader.GetDecimal(2) });
            }
            return туры;
        }
    }
}
