﻿using Microsoft.Maui.Controls;
using System;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnShowListClicked(object sender, EventArgs e)
        {
            // Скрываем оба списка перед обновлением
            listViewDisplay.IsVisible = false;
            textBoxDisplay.IsVisible = false;

            // Данные списка
            var items = new string[] { "Элемент 1", "Элемент 2", "Элемент 3" };

            if (radioListBox.IsChecked)
            {
                listViewDisplay.ItemsSource = items;
                listViewDisplay.IsVisible = true;
            }
            else if (radioTextBox.IsChecked)
            {
                textBoxDisplay.Text = string.Join(", ", items);
                textBoxDisplay.IsVisible = true;
            }
        }
    }
}
