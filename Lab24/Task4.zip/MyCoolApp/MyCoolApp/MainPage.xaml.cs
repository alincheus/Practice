﻿using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;
using System;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCreateClicked(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(inputLetter.Text) ||
                !double.TryParse(inputX.Text, out double x) ||
                !double.TryParse(inputY.Text, out double y))
            {
                DisplayAlert("Ошибка", "Введите корректные данные!", "ОК");
                return;
            }

            string type = inputLetter.Text.ToUpper();
            View newElement = null;

            if (type == "К")  
            {
                newElement = new Button
                {
                    Text = "Кнопка",
                    BackgroundColor = Colors.Red,
                    WidthRequest = 100,
                    HeightRequest = 40
                };
            }
            else if (type == "П") 
            {
                newElement = new Entry
                {
                    Placeholder = "Поле ввода",
                    BackgroundColor = Colors.Yellow,
                    WidthRequest = 120
                };
            }
            else if (type == "М")  
            {
                newElement = new Label
                {
                    Text = "Метка",
                    BackgroundColor = Colors.Green,
                    FontSize = 18
                };
            }
            else
            {
                DisplayAlert("Ошибка", "Введите К, П или М!", "ОК");
                return;
            }

            newElement.Margin = new Thickness(x, y, 0, 0);

            var tapGesture = new TapGestureRecognizer();
            tapGesture.Tapped += (s, e) => ElementContainer.Children.Remove((View)s);
            newElement.GestureRecognizers.Add(tapGesture);

            ElementContainer.Children.Add(newElement);
        }
    }
}
