﻿using Microsoft.Maui.Controls;
using System;
using System.Text;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private int[,] matrix = new int[3, 4];

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnGenerateMatrixClicked(object sender, EventArgs e)
        {
            Random rnd = new Random();
            StringBuilder matrixOutput = new StringBuilder("Исходная матрица:\n");
            StringBuilder minValuesOutput = new StringBuilder("Минимальные элементы в строках:\n");

            for (int i = 0; i < 3; i++)
            {
                int min = int.MaxValue;
                for (int j = 0; j < 4; j++)
                {
                    matrix[i, j] = rnd.Next(1, 100);
                    matrixOutput.Append($"{matrix[i, j],4} ");
                    if (matrix[i, j] < min)
                    {
                        min = matrix[i, j];
                    }
                }
                matrixOutput.AppendLine();
                minValuesOutput.AppendLine($"Строка {i + 1}: {min}");
            }

            matrixLabel.Text = matrixOutput.ToString();
            resultLabel.Text = minValuesOutput.ToString();
        }
    }
}
