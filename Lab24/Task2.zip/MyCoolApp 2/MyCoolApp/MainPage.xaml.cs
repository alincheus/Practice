﻿using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;
using System;
using System.Collections.Generic;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private List<PointF> dataPoints = new();

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnDrawGraphClicked(object sender, EventArgs e)
        {
            if (!float.TryParse(inputA.Text, out float a) ||
                !float.TryParse(inputB.Text, out float b) ||
                !float.TryParse(inputH.Text, out float h))
            {
                DisplayAlert("Ошибка", "Введите корректные параметры!", "ОК");
                return;
            }

            dataPoints.Clear();

            for (float x = -10; x <= 10; x += h)
            {
                float y = a * x + b;
                dataPoints.Add(new PointF(x, y));
            }

            GraphView.Invalidate();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            GraphView.Drawable = new GraphDrawable(dataPoints);
        }
    }

    class GraphDrawable : IDrawable
    {
        private readonly List<PointF> points;

        public GraphDrawable(List<PointF> dataPoints)
        {
            points = dataPoints;
        }

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.FillColor = Colors.White;
            canvas.FillRectangle(dirtyRect);

            canvas.StrokeColor = Colors.Black;
            canvas.DrawLine(0, dirtyRect.Height / 2, dirtyRect.Width, dirtyRect.Height / 2);
            canvas.DrawLine(dirtyRect.Width / 2, 0, dirtyRect.Width / 2, dirtyRect.Height);

            canvas.StrokeColor = Colors.Blue;
            for (int i = 1; i < points.Count; i++)
            {
                float scaleX = dirtyRect.Width / 20;  
                float scaleY = dirtyRect.Height / 20; 

                float x1 = (points[i - 1].X * scaleX) + dirtyRect.Width / 2;
                float y1 = dirtyRect.Height / 2 - (points[i - 1].Y * scaleY);

                float x2 = (points[i].X * scaleX) + dirtyRect.Width / 2;
                float y2 = dirtyRect.Height / 2 - (points[i].Y * scaleY);

                canvas.DrawLine(x1, y1, x2, y2);
            }
        }
    }
}
