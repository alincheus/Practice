﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.Maui.Controls;

namespace MyGreatApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void CountBinaryNumbers(object sender, System.EventArgs e)
        {
            int zeroCount = 0;
            int oneCount = 0;

            if (listBox.ItemsSource is IEnumerable<string> items)
            {
                foreach (var binaryString in items)
                {
                    zeroCount += binaryString.Count(c => c == '0');
                    oneCount += binaryString.Count(c => c == '1');
                }
            }

            resultLabel.Text = $"Нулей: {zeroCount}, Единиц: {oneCount}";
        }

    }
}
