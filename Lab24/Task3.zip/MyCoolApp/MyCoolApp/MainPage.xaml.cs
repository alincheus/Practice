﻿using Microsoft.Maui.Graphics;
using Microsoft.Maui.Controls;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            HouseView.Drawable = new HouseDrawable();
        }
    }

    class HouseDrawable : IDrawable
    {
        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.FillColor = Colors.White;
            canvas.FillRectangle(dirtyRect);

            // Основной дом (Прямоугольник)
            canvas.FillColor = Colors.Brown;
            canvas.FillRectangle(100, 150, 200, 120);

            // Крыша (Треугольник)
            canvas.FillColor = Colors.Red;
            PathF roof = new PathF();
            roof.MoveTo(80, 150);
            roof.LineTo(200, 50);
            roof.LineTo(320, 150);
            roof.Close();
            canvas.FillPath(roof);

            // Дверь
            canvas.FillColor = Colors.DarkGray;
            canvas.FillRectangle(180, 200, 40, 70);

            // Окна
            canvas.FillColor = Colors.LightBlue;
            canvas.FillRectangle(120, 170, 40, 40);
            canvas.FillRectangle(240, 170, 40, 40);

            // Контуры окон и двери
            canvas.StrokeColor = Colors.Black;
            canvas.DrawRectangle(120, 170, 40, 40);
            canvas.DrawRectangle(240, 170, 40, 40);
            canvas.DrawRectangle(180, 200, 40, 70);
        }
    }
}
