﻿using Microsoft.Maui.Controls;
using System;
using System.Linq;
using System.Text;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        private int[] numbers = new int[20];

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnGenerateArrayClicked(object sender, EventArgs e)
        {
            Random rnd = new Random();
            StringBuilder originalOutput = new StringBuilder("Исходный массив:\n");
            StringBuilder modifiedOutput = new StringBuilder("Измененный массив:\n");

            for (int i = 0; i < 20; i++)
            {
                numbers[i] = rnd.Next(1, 100);
                originalOutput.Append($"{numbers[i]} ");
            }

            int maxIndex = numbers.ToList().IndexOf(numbers.Max());

            (numbers[0], numbers[maxIndex]) = (numbers[maxIndex], numbers[0]);

            foreach (var num in numbers)
            {
                modifiedOutput.Append($"{num} ");
            }

            originalArrayLabel.Text = originalOutput.ToString();
            modifiedArrayLabel.Text = modifiedOutput.ToString();
        }
    }
}
