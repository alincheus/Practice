﻿using Microsoft.Maui.Controls;
using System;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnSaveClicked(object sender, EventArgs e)
        {
            string employeeData = $"Анкетные данные сотрудника:\n" +
                                  $"Фамилия: {inputLastName.Text}\n" +
                                  $"Имя: {inputFirstName.Text}\n" +
                                  $"Отчество: {inputMiddleName.Text}\n" +
                                  $"Пол: {genderPicker.SelectedItem}\n" +
                                  $"Дата рождения: {birthDatePicker.Date:dd MMMM yyyy}\n" +
                                  $"Место проживания: {inputResidence.Text}\n" +
                                  $"Email: {inputEmail.Text}\n" +
                                  $"Телефон: {inputPhone.Text}\n" +
                                  $"Опыт работы: {experiencePicker.SelectedItem}\n" +
                                  $"Личное авто: {(hasCarCheckBox.IsChecked ? "Да" : "Нет")}\n" +
                                  $"Водительские права: {(hasLicenseCheckBox.IsChecked ? "Да" : "Нет")}\n" +
                                  $"Категория прав: {licenseCategoryPicker.SelectedItem}\n" +
                                  $"Зарплата: От {inputSalaryFrom.Text} до {inputSalaryTo.Text}\n" +
                                  $"График работы: {schedulePicker.SelectedItem}\n" +
                                  $"Резюме: {inputResume.Text}";

            Console.WriteLine(employeeData);
            DisplayAlert("Успех", "Данные сохранены!", "ОК");
        }

        private void OnClearClicked(object sender, EventArgs e)
        {
            inputLastName.Text = "";
            inputFirstName.Text = "";
            inputMiddleName.Text = "";
            inputResidence.Text = "";
            inputEmail.Text = "";
            inputPhone.Text = "";
            inputSalaryFrom.Text = "";
            inputSalaryTo.Text = "";
            inputResume.Text = "";
            genderPicker.SelectedIndex = -1;
            experiencePicker.SelectedIndex = -1;
            schedulePicker.SelectedIndex = -1;
            licenseCategoryPicker.SelectedIndex = -1;
            hasCarCheckBox.IsChecked = false;
            hasLicenseCheckBox.IsChecked = false;
        }
    }
}
