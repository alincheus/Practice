﻿using Microsoft.Maui.Graphics;

namespace MyCoolApp
{
    public class ShapeDrawable : IDrawable
    {
        private static readonly float CircleCenterX = 100, CircleCenterY = 100, CircleRadius = 50;
        private static readonly float TriangleLeftX = 250, TriangleTopY = 50, TriangleRightX = 350, TriangleBottomY = 150;
        private static readonly float PyramidBaseLeftX = 450, PyramidBaseRightX = 550, PyramidTopX = 500, PyramidBaseY = 150, PyramidTopY = 50;

        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.StrokeSize = 4;
            canvas.StrokeColor = Colors.Black;

            canvas.FillColor = Colors.DeepSkyBlue;
            canvas.FillCircle(CircleCenterX, CircleCenterY, CircleRadius);
            canvas.DrawCircle(CircleCenterX, CircleCenterY, CircleRadius);

            canvas.FillColor = Colors.LimeGreen;
            var trianglePath = new PathF();
            trianglePath.MoveTo(TriangleLeftX, TriangleBottomY);
            trianglePath.LineTo((TriangleLeftX + TriangleRightX) / 2, TriangleTopY);
            trianglePath.LineTo(TriangleRightX, TriangleBottomY);
            trianglePath.Close();
            canvas.FillPath(trianglePath);
            canvas.DrawPath(trianglePath);

            canvas.FillColor = Colors.OrangeRed;
            var pyramidPath = new PathF();
            pyramidPath.MoveTo(PyramidBaseLeftX, PyramidBaseY);
            pyramidPath.LineTo(PyramidTopX, PyramidTopY);
            pyramidPath.LineTo(PyramidBaseRightX, PyramidBaseY);
            pyramidPath.Close();
            canvas.FillPath(pyramidPath);
            canvas.DrawPath(pyramidPath);
        }

        public static bool IsInsideCircle(float x, float y)
        {
            return ((x - CircleCenterX) * (x - CircleCenterX) + (y - CircleCenterY) * (y - CircleCenterY)) <= CircleRadius * CircleRadius;
        }

        public static bool IsInsideTriangle(float x, float y)
        {
            return x > TriangleLeftX && x < TriangleRightX && y > TriangleTopY && y < TriangleBottomY;
        }

        public static bool IsInsidePyramid(float x, float y)
        {
            return x > PyramidBaseLeftX && x < PyramidBaseRightX && y > PyramidTopY && y < PyramidBaseY;
        }
    }
}
