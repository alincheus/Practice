﻿using Microsoft.Maui.Controls;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            CanvasView.Drawable = new ShapeDrawable();

            var tapGesture = new TapGestureRecognizer();
            tapGesture.Tapped += OnShapeTapped;
            CanvasView.GestureRecognizers.Add(tapGesture);
        }

        private void OnShapeTapped(object sender, TappedEventArgs e)
        {
            var position = e.GetPosition((View)sender);
            if (position == null) return;

            float x = (float)position.Value.X;
            float y = (float)position.Value.Y;

            if (ShapeDrawable.IsInsideCircle(x, y))
                DisplayAlert("Кнопка", "Ты нажал на круглую кнопку!", "OK");
            else if (ShapeDrawable.IsInsideTriangle(x, y))
                DisplayAlert("Кнопка", "Ты нажал на треугольную кнопку!", "OK");
            else if (ShapeDrawable.IsInsidePyramid(x, y))
                DisplayAlert("Кнопка", "Ты нажал на кнопку-пирамиду!", "OK");
        }
    }
}
