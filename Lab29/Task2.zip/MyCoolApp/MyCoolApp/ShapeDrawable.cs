﻿using Microsoft.Maui.Graphics;

namespace MyCoolApp
{
    public class ShapeDrawable : IDrawable
    {
        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.StrokeSize = 4;
            canvas.StrokeColor = Colors.Black;

            canvas.DrawCircle(100, 100, 60);
            canvas.DrawCircle(100, 100, 40);
            canvas.DrawCircle(100, 100, 20);

            for (int i = 0; i < 5; i++)
            {
                canvas.DrawRectangle(200 + i * 20, 100 + i * 20, 60, 60);
            }

            int size = 40;
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    if ((row + col) % 2 == 0)
                        canvas.FillColor = Colors.Black;
                    else
                        canvas.FillColor = Colors.White;

                    canvas.FillRectangle(350 + col * size, 100 + row * size, size, size);
                }
            }
        }
    }
}
