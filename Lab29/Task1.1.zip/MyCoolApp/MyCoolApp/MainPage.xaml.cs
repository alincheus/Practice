﻿using Microsoft.Maui.Controls;

namespace MyCoolApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            CanvasView.Drawable = new ShapeDrawable();
        }
    }
}
