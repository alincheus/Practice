﻿using Microsoft.Maui.Graphics;

namespace MyCoolApp
{
    public class ShapeDrawable : IDrawable
    {
        public void Draw(ICanvas canvas, RectF dirtyRect)
        {
            canvas.FillColor = Colors.Blue;
            var trianglePath = new PathF();
            trianglePath.MoveTo(50, 50);
            trianglePath.LineTo(150, 20);
            trianglePath.LineTo(250, 50);
            trianglePath.Close();
            canvas.FillPath(trianglePath);

            canvas.FillColor = Colors.Red;
            canvas.FillEllipse(300, 50, 150, 80);

            canvas.FillColor = Colors.Green;
            canvas.FillCircle(100, 200, 50);

            canvas.FillColor = Colors.Orange;
            canvas.FillRectangle(300, 200, 120, 80);

            canvas.FillColor = Colors.Purple;
            canvas.FillArc(500, 100, 100, 100, 0, 90, true);
        }
    }
}
